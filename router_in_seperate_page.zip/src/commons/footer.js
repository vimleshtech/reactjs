
import React,{Component} from 'react';

class Footer extends Component{

    render(){

        return(<div> <h2> footer works </h2></div>)
    }

}

export default Footer;
