import React,{Component} from 'react';

class NoMatch extends Component{

    constructor(){
        super()
    }

    render(){

        return(<div> <h1> no match </h1></div>)
    }
}


export default NoMatch;