import React,{Component} from 'react';

class About extends Component{

    constructor(){
        super()
    }

    render(){

        return(<div> <h1> About us </h1></div>)
    }
}


export default About;