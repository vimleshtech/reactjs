import React,{Component} from 'react';

class Users extends Component{

    constructor(){
        super()
    }

    render(){

        return(<div> <h1> Users </h1></div>)
    }
}


export default Users;