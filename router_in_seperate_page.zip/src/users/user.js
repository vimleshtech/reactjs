
import React,{Component} from 'react';

class User extends Component{

    render(){

        return(<div> <h2> user works </h2></div>)
    }

}

export default User;
