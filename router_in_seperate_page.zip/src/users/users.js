
import React,{Component} from 'react';

class Users extends Component{

    render(){

        return(<div> <h2> users works </h2></div>)
    }

}

export default Users;
