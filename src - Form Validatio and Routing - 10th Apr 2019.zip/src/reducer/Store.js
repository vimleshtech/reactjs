
const data = (state = [], action) => 
{
    switch(action.type) {

      case 'add':

        return state.concat([action.data]);

      default:
        
        return state;

    }
  }
  export default data;
