import React,{Component} from 'react';

import {connect} from 'react-redux';

class Product extends Component {


    frm_submit=()=>{

        var name = this.refs.name.value;

        console.log(name);



        const data = {
            id: new Date(),
            name
            
          }
          this.props.dispatch({
            type:'add',
            data});
      



    }

    render(){

        return(
            <div>

            <p>

                <input type="text" ref="name" />
                
                </p>

                <p>

                <input type="button" value="Submit" onClick={this.frm_submit}   />
                
                </p>

            </div>
        );
    }


}

export  default connect()(Product);
