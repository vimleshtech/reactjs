import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import Product from './Product';
import ProductList from './ProductList';

import Customer from './Customer';


import { BrowserRouter as Router, Route,Link } from 'react-router-dom';


class App extends Component {
  render() {
    return (
      <div className="App">

    <Router>
      <div>
        <Route exact path="/" component={Customer} />
        <Route path="/product" component={Product} />
        <Route path="/list" component={ProductList} />
 
      </div>
      <Link to="/"><button>Customer</button></Link>
      <Link to="/product"><button>Product</button></Link>
      <Link to="/list"><button>List</button></Link>

    </Router>




{/*       
        <Customer/>
          <Product/>
          <ProductList/> */}
          
      </div>
    );
  }
}

export default App;
