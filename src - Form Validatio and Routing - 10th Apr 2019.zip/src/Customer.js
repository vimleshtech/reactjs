import React, {Component} from 'react';


export default class Customer extends Component{


    constructor(){

        super();
            
            this.state ={

                name_val:true,
                email_val:true,
                pwd_val:true,
            }
        
        }

        
    frm_submit=()=>{

        var name = this.refs.name.value;
        var email = this.refs.email.value;
        var phone = this.refs.phone.value;
        var pwd = this.refs.pwd.value;

        if(name === ''){

            this.refs.msg_name.innerHTML="Name cannnot be blank";
        }
        else{

            this.refs.msg_name.innerHTML="";
        }


        ///
        
        if(email === ''){

            this.setState({email_val:false});

        }
        else{

            this.setState({email_val:true});
        }

       // console.log(name,email,phone,pwd, this.state.email_val);

    }
    render(){

        var e = this.state.email_val;

        return(

            <div>
                        <p> Name : <input type="text" ref="name"/><span className="frm_msg" ref="msg_name">  </span> </p>
                        <p> Email  : <input type="text" ref="email"/>
                            {this.state.email_val==false? <span className="frm_msg"> Not allow null </span> : true }
                         </p>
                        <p> Phone : <input type="text" ref="phone"/> </p>
                        <p> Password : <input type="text" ref="pwd"/> </p>
                        <p> 
                            <input type="button" onClick={this.frm_submit} value="Register" />
                        </p>


            </div>


        );
    }

}