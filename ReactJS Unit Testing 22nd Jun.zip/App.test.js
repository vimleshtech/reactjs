import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';


describe('App',()=>{

  it('add-validate-1', () => {
  
    expect(2 + 2).toBe(4);

  });

//   it('tax-validate',()=>{

//     const obj = new App();
//     expect(obj.frm_test(1200000)).toBe(170000);

//   })
//   it('add-validate-2', () => {
    
  
//     expect(2 + 2).toBe(9);

//     });

// it('sub-validate', () => {
  
//   //expect(2 + 2).toBe(4);
//   console.log('sub');

// });


// it('mul-validate', () => {
  
//   console.log('mul');

// });

})


// it('renders without crashing', () => {
  
//   const div = document.createElement('div');
//   ReactDOM.render(<App />, div);
//   ReactDOM.unmountComponentAtNode(div);

// });
