export const bAction =(val)=> {
    return {type: "DOWN",    value: val}
  };