import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ReactDOM from 'react-dom';
import  Contact from './Contact'
class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>

        <a href="ContactPage" >Contact Page </a>

        <Signin/>

        <Signup/>
        <Products/>

        <hr/>
        <ColorEx/>
        <hr/>
        <EventsEx/>
        <Footer/>
        

      </div>
    );
  }
}

class Signin extends Component
{


  constructor() {
    super();

    this.state = {

      email: '',
      password: '',      

      eerrror:false, 
      perrror:false, 

      isDisabled:true,
      
    };
  }
   
  handleEmailChange = (evt) => {    
    
    this.setState({ email: evt.target.value }); 
    //alert("test");
    console.log("you have entered data ");


  
  }
  
  handlePasswordChange = (evt) => {
    this.setState({ password: evt.target.value });    

    if(!this.state.eerrror && !this.state.perrror)
      this.setState({isDisabled:false});
    else 
      this.setState({isDisabled:true});
  }
  

  handleSubmit = (evt) => {

    if(this.state.email.length==0)

      this.setState({eerrror:true});
    else
      this.setState({eerrror:false});

     if( this.state.password.length==0)    
      this.setState({perrror:true});
      else
      this.setState({perrror:false});
    
  
  }
  
  
  render(){

    return(
      <div>

      <input
        className={this.state.eerrror ? "error" : "txt"}
        type="text"
        placeholder="Enter email"
        value={this.state.email}

        onChange={this.handleEmailChange}
      />
      
      <input
        
        type="password"
        className={this.state.perrror ? "error" : "txt"}
        placeholder="Enter password"
        value={this.state.password}
        onChange={this.handlePasswordChange}
      />
      <button onClick={this.handleSubmit} 
      disabled={this.state.isDisabled} >Sign up</button>

      <p>
        Email Id : {this.state.email}
      </p>
      <p>
        Password : {this.state.password}
      </p>

    </div>
    );
  }
}


class Signup extends Component{


  constructor() {
    super();
    this.state = {
       data: 
       [
          {
             "id":1,
             "name":"Foo",
             "age":"20"
          },
          {
             "id":2,
             "name":"Bar",
             "age":"30"
          },
          {
             "id":3,
             "name":"Baz",
             "age":"40"
          }
       ]
    }
 }


  render(){

    var myStyle = {
      fontSize: 40,
      color: '#FF0000',
      
   }


    return(
          <div>
          <p>
                Name : <input type="text" />
          </p>
          <p>
                Email Id : <input type="text" />
          </p>
          <p>
                Contact No : <input type="text" />
          </p>
          
          <p>
                Password : <input type="password" />
          </p>

          <p>
               Conf Password : <input type="password" />
          </p>
          <p>
                <input style = {myStyle}  type="submit" value="Submit" />
          </p>
          <p>

        <table>
        <tbody>
        
        {this.state.data.map((person, i) => <TableRow key = {i} 
                     data = {person} />)}
               </tbody>
            </table>

            </p>
      </div>

    );
  }
}
class Footer extends Component{

  constructor(props) {
    super(props);
  
    this.state = {
       header: "Header from state...",
       content: "Content from state..."
    }
 }


  render(){ 
    var i = 1;
    return(
        <div >
          <p>
              All Copy rights reserved @2018
            </p>
            <p>
                {this.state.header} {this.state.content}
            </p>

            <p>
            <h1>{1+1}</h1>
              </p>
              
              <h1>{i == 1 ? 'True!' : 'False'}</h1>

        </div>
    );
  }
  
}

class TableRow extends React.Component {
  render() {
     return (
        <tr>
           <td>{this.props.data.id}</td>
           <td>{this.props.data.name}</td>
           <td>{this.props.data.age}</td>
        </tr>
     );
  }
}


class Products extends Component
{
    constructor() {

          super();      
          this.state = {
          data: []
          }

          this.setStateHandler = this.setStateHandler.bind(this);
          this.forceUpdateHandler = this.forceUpdateHandler.bind(this);

      };

  setStateHandler() {

    var item = "Item-1"

    var myArray = this.state.data.slice();

    myArray.push(item);
    this.setState({data: myArray})

 };

 forceUpdateHandler() {
  this.forceUpdate();
};


 render() {
    return (
       <div>
          <button onClick = {this.setStateHandler}>SET STATE</button>

          <h4>State Array: {this.state.data}</h4>


           <button onClick = {this.forceUpdateHandler}>FORCE UPDATE</button>
            <h4>Random number: {Math.random()}</h4>

       </div>
    );
 }

}



class ColorEx extends Component {
  constructor() {
     super();
     this.findDomNodeHandler = this.findDomNodeHandler.bind(this);
  };
  findDomNodeHandler() {
     var myDiv = document.getElementById('myDiv');
     ReactDOM.findDOMNode(myDiv).style.color = 'green';
  }
  render() {
     return (
        <div>
           <button onClick = {this.findDomNodeHandler}>FIND DOME NODE</button>
           <div id = "myDiv">NODE</div>
        </div>
     );
  }
}


class EventsEx extends React.Component {
  constructor(props) {
     super(props);
     
     this.state = {
        data: 0,
        name: 'Initial data...',
        test:'test'
       
 
     }
     this.testEve = this.testEve.bind(this)
     this.updateState = this.updateState.bind(this);
  };
  updateState(e) {
    this.setState({name: e.target.value});
 }

  testEve() {
     this.setState({data: this.state.data + 1})
  }
  render() {
     return (
        <div>
           <button onClick = {this.testEve}>INCREMENT</button>
           <Content myNumber = {this.state.data}></Content>

           <hr/>
           <input type = "text" value = {this.state.data} 
               onChange = {this.updateState} />
            <h4>{this.state.data}</h4>

        </div>
     );
  }
}
class Content extends React.Component {
  componentWillMount() {
     console.log('Component WILL MOUNT!')
  }
  componentDidMount() {
     console.log('Component DID MOUNT!')
  }
  componentWillReceiveProps(newProps) {    
     console.log('Component WILL RECIEVE PROPS!')
  }
  shouldComponentUpdate(newProps, newState) {
     return true;
  }
  componentWillUpdate(nextProps, nextState) {
     console.log('Component WILL UPDATE!');
  }
  componentDidUpdate(prevProps, prevState) {
     console.log('Component DID UPDATE!')
  }
  componentWillUnmount() {
     console.log('Component WILL UNMOUNT!')
  }
  render() {
     return (
        <div>
           <h3>{this.props.myNumber}</h3>
        </div>
     );
  }
}


export default App;
