import React from 'react';
import ReactDOM from 'react-dom';

import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';

import './index.css';
import App from './App';
import Contact from './Contact';
import registerServiceWorker from './registerServiceWorker';

const root = document.getElementById('root');


  
  const RoutedApp = () => (
    <BrowserRouter >
      <Switch>
        {/* <Route path="/items/:id" component={AppPage} /> 

        <Route exact path="/AppPage" component={App} /> */}
        <Route exact path="/ContactPage" component={Contact} />          
        
        {/* <Route path="/yourReactComp" component={YourReactComp} /> */}
        <Route exact path="/" render={() => (<Redirect to="/items" />)} />          
        <Route path="*" component={App} />        

      </Switch>
    </BrowserRouter>
  );
  ReactDOM.render(<RoutedApp />, root); 

//ReactDOM.render(<App />, document.getElementById('root'));

registerServiceWorker();
