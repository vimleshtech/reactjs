
import React,{Component} from 'react';

import ProductShow from './product-show';


class ProdctCreate extends Component{

    constructor()
    {
        super();
        this.state={
            pid:'',
            pname:'',
            pprice:'',
            products:[]
        }

        //this.test =  this.frm.bind(this);
    }


    frm_submit=()=>{

        var id = this.refs.id.value;
        var name = this.refs.name.value;
        var price =this.refs.price.value;
        
        this.setState({pid:id,pname:name,pprice:price});

        var products = this.state.products;
        products.push({pid:id,pname:name,pprice:price});
        this.setState({products:products});

        console.log(this.state.products);

        //alert(id);
    }

    frm_delete=(e)=>{

        //alert(e);
        var products = this.state.products.filter(x=> x.pid != e);
        this.setState({products:products});


    }
    frm_edit=(e)=>{

        var products = this.state.products.filter(x=> x.pid == e);
        this.refs.id.value = products[0].pid;
        this.refs.name.value = products[0].pname;
        this.refs.price.value = products[0].pprice;

    }

    /*
    frm(){
        
                alert('hello');
    }
    */

    render(){

        return(

            <div>
                <h1> New Product  {this.state.name} </h1>
                <p>
                    Product ID : <input  className="form-control" type="text"  ref="id"/>
                </p>
                <p>
                    Product Name : <input type="text" ref="name"/>
                </p>
                <p>
                    Product Price : <input type="text" ref="price"/>
                </p>
                <p>
                   <input type="button" onClick={this.frm_submit}  value="Add Product" />
                </p>
                
                <div>
                    {this.state.pid}
                    {this.state.pname}
                    {this.state.pprice}

                </div>

                    <div>
                        {this.state.products.map((item,i)=>

                            <ProductShow key={i} frm_delete={this.frm_delete} 
                            frm_edit={this.frm_edit} 
                            rowitem={item}  />
                         )}
                    </div>
            </div>

        );
    }
}

export default ProdctCreate;

