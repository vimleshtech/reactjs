import React,{Component} from 'react';


export default class ProductShow extends Component
{
    
    render(){

        return(
                <div>
                        {this.props.rowitem.pid}
                        {this.props.rowitem.pname}
                        {this.props.rowitem.pprice}
                        <input type="button"  value="Edit" onClick={()=>this.props.frm_edit(this.props.rowitem.pid)}/>
                        <input type="button" value="Delete"  onClick={()=>this.props.frm_delete(this.props.rowitem.pid)}/>


                </div>

        );
    }

}