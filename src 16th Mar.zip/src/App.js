import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';


import ProductCreate from './components/product-create';

class App extends Component {
  render() {
    return (
   
      <div>
          <ProductCreate/>

      </div>

    );
  }
}

export default App;
