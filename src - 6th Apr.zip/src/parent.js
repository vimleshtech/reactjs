import React, { Component } from 'react';
import Child from'./child.js';

class Parent extends Component {
  constructor(){
        super();
        this.state={};
        this.state.emp=[
            {id:11,data:'a'},
            {id:12,data:'b'},
            {id:13,data:'c'}
        ];
        this.state.selectedEmp=[];
        this.clicked = this.clicked.bind(this);
      }

  clicked(data){
      
        console.log(data);
            var d = this.state.selectedEmp;
            d =d+data;
            this.setState({selectedEmp:d});
            console.log('this.state.selectedEmp',this.state.selectedEmp)
        }

  render() {
    return (
      <div>
        {this.state.emp.map((emp, index) => (<Child clicked={this.clicked} data={emp}/> ))}
      </div>
    );
  }
}

export default Parent;
