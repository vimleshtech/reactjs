import React, { Component } from 'react';


//impoert other file file 
//. : current folder 
import Header from './components/header/header';
import Footer from './components/fotoer/footer';
import Body from './components/body/body';
import Nav from './components/nav/nav';



class App extends Component {

  render() {
    return (
   


      <div>

      

      <Header/>
      <Body/>
      <Nav/>
      <Footer/>
      

      </div>




    );
  }
}

export default App;
