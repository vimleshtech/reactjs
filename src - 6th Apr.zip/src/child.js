import React, { Component } from 'react';
import Parent from'./parent.js';

class Child extends Component {

constructor()
{
    super();
    this.childFun  = this.childFun.bind(this);
}

childFun(){
    console.log('child fun');
}
  render() {
    return (
      <div>
        <input type="button" onClick={ () => this.props.clicked(this.props.data) } value={this.props.data.id}/>
      </div>
    );
  }
}

export default Child;
