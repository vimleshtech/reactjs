

import React,{Component} from 'react';


export default class HeaderLeft extends Component{



    render(){
    return(


                <div>

                    <h1> Header  Left</h1>
                </div>

    );


    
    }


}