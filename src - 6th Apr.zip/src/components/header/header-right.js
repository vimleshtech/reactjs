

import React,{Component} from 'react';


export default class HeaderRight extends Component{



    render(){
    return(


                <div>

                    <h1> Hreader Right </h1>
                </div>

    );


    
    }


}