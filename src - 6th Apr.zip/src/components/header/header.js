

import React,{Component} from 'react';


import HeaderLeft  from './header-left';
import HeaderRight  from './header-right';

import './header.css';


export default class Header extends Component{


    render(){
    return(


                <div className="hd">

                   <HeaderRight/>
                   <HeaderLeft/>

                </div>

    );


    
    }


}