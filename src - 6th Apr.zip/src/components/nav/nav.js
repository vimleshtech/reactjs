

import React,{Component} from 'react';


export default class Nav extends Component{



    render(){
    return(


                <div>

                    <h1> nav </h1>
                </div>

    );


    
    }


}