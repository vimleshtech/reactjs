

import React,{Component} from 'react';


export default class ContentMain extends Component{



    render(){
    return(


                <div>

                    <h1> Content Main </h1>
                </div>

    );


    
    }


}