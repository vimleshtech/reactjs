

import React,{Component} from 'react';


import ContentMain from './content-main';
import ContentTop from './content-top';


export default class Body extends Component{



    render(){
    return(


                <div>
                    <ContentTop/>
                    <ContentMain/>
                    

                </div>

    );


    
    }


}