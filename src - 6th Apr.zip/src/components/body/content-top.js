

import React,{Component} from 'react';


export default class ContentTop extends Component{



    render(){
    return(


                <div>

                    <h1> Content Top </h1>
                </div>

    );


    
    }


}