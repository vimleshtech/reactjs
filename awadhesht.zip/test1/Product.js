import React, { Component } from 'react';
import Productlist from './Productlist';
import Productview from './Productview';
import Productupdate from './Productupdate';

class Product extends React.Component {
  constructor() {
     super();
     this.state = {
        Productdata: 
        [
           {
            "id":1,
            "name":"Jeans",
            "price":"20",
            "Instock":true
           },
           {
            "id":2,
            "name":"Pant",
            "price":"30",
            "Instock":false
           },
           {
            "id":3,
            "name":"Shirt",
            "price":"40",
            "Instock":true
           },
           {
            "id":4,
            "name":"Tshirt",
            "price":"20",
            "Instock":true
         },
         {
            "id":5,
            "name":"Shoes",
            "price":"30",
            "Instock":false
         },
         {
            "id":6,
            "name":"Shocks",
            "price":"40",
            "Instock":true
         }
        ],
        Selectedproduct: [],
        newdata:[]
     }
  }
 updateCart (data){
   console.log('out ',data)
   console.log(typeof(data))
   var dd = this.state.newdata;
   console.log('out 2 :',dd)
   dd.push(data);
   this.setState({newdata:dd});
   console.log('this.state',this.state.newdata);
}


  render() {
     return (
       <div className="productContainer row">
          <div className="col-sm-4 product"> Product List
            {this.state.Productdata.map((val,i) => <Productlist key={i} data={val}/>)}
          </div>

          <div className="col-sm-4 product">Product View
            {this.state.Selectedproduct.map((val,i) => <Productview key={i} data={val}/>)}
          </div>

        </div> 
     );
  }
}
export default Product;
