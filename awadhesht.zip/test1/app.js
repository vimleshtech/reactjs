import React, { Component } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Header from './Header';
import Footer from './Footer';
import Product from './test1/Product';

class App extends Component {
  render() {
    return (
      <div>
        <Header/>
          <Product/>
        <Footer/>
      </div>
    );
  }
}

export default App;
