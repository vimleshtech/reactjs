import React, { Component } from 'react';
import Product from './Product';
import Productlistchild from './Productlistchild';


class Productlist extends React.Component {
  constructor(props) {
      super(props);
      this.state = {
         Productdata: []
      }
      this.productSelection=this.productSelection.bind(this);
  }
   productSelection(e){
      var selectedProduct = new Product();
      selectedProduct.updateCart(e);
   }

   render() {
      return (
         <div>
            {this.props.data.name}<input type="checkbox" className="chk" onChange={e => this.productSelection(this.props.data)}/>
         </div>
        //<Productlistchild/>
      );
   }
}

export default Productlist;
