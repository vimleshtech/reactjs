import React, { Component } from 'react';
class Productupdate extends React.Component {
  constructor() {
     super();
     
  }
  render() {
    if(this.props.data.Instock){
      var str=<div>{this.props.data.name}</div>;
    }
     return (
        <div>
             {str}
       </div>
     );
  }
}
export default Productupdate;
