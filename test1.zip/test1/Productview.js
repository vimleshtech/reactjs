import React, { Component } from 'react';

class Productview extends React.Component {
  constructor(props) {
     super(props);
  }


  render() {
     return (
        <div>
          <input type="checkbox"/> Awadhesh
        </div>  
       );
  }
}
export default Productview;
