import React,{Component} from 'react';

//ChildB component
class ChildB extends Component {
    render() {

        var handleToUpdate  =   this.props.handleToUpdate;
        return (<div>
          <button onClick={() => handleToUpdate('someVar')}>
            Push me
          </button>
        </div>)
    }
}

//ParentA component
class ParentA extends Component { 
    constructor(props) {
        super(props);
        this.state={data:''};
    }

    handleToUpdate = (someArg) => {
            alert('We pass argument from Child to Parent: ' + someArg);
            this.setState({data:someArg});

            alert(this.state.data);


            this.setState({
                data: 'someValue'
              });


            alert(this.state.data);


    }

    render() {
        return (<div>
            <ChildB handleToUpdate = {this.handleToUpdate} /></div>)
    }
}

export default ParentA;
