import React, { Component } from 'react';
import Productlist from './Productlist';

class Productlistchild extends React.Component {
  constructor(props) {
      super(props);
      
      this.productChildSelection=this.productChildSelection.bind(this);
  }
   productChildSelection(e){
     alert('productChildSelection');
     var selectedProductchild = new Productlist();
     selectedProductchild.updateCart(e);

   }

   render() {
      return (
         <div>
            <input type="button" onChange={e => this.productChildSelection(this)}/>
         </div>
      );
   }
}

export default Productlistchild;
