import React, { Component } from 'react';
import Productlist from './Productlist';
import Productview from './Productview';
import Productupdate from './Productupdate';

class Product extends React.Component {
  constructor() {
     super();
     this.state = {
        Productdata: 
        [
           {
            "id":1,
            "name":"Jeans",
            "price":"20",
            "Instock":true
           },
           {
            "id":2,
            "name":"Pant",
            "price":"30",
            "Instock":false
           },
           {
            "id":3,
            "name":"Shirt",
            "price":"40",
            "Instock":true
           },
           {
            "id":4,
            "name":"Tshirt",
            "price":"20",
            "Instock":true
         },
         {
            "id":5,
            "name":"Shoes",
            "price":"30",
            "Instock":false
         },
         {
            "id":6,
            "name":"Shocks",
            "price":"40",
            "Instock":true
         }
        ],
        Selectedproduct: [],
        newdata:[]
     };
  }
 updateCart (data){

    //localStorage.removeItem("list");
    //console.log('data1',JSON.stringify(data));
    //console.log('data2',JSON.parse(JSON.stringify(data)));
    

    if(localStorage.getItem("list")=== null)
   {
      localStorage.setItem("list",JSON.stringify(data));
   }
   else
   {
      var ldata = localStorage.getItem("list");

      ldata+=","+JSON.stringify(data);
      localStorage.setItem("list",ldata);
   }
  var obj = "["+localStorage.getItem("list")+"]";
  // console.log(obj)
   obj = eval(obj);
   //console.log(typeof(obj));


   
   var dd = this.state.newdata;
   console.log('out 2 :',dd)
   dd.push(data);
   
   this.setState({newdata: dd});
   console.log('this.state',this.state.newdata);

}


  render() {
     return (
       <div className="productContainer row">
          <div className="col-sm-4 product"> Product List
            {this.state.Productdata.map((val,i) => <Productlist key={i} data={val}/>)}
          </div>
          <div>

             <button>Del</button>
          </div>

          <div className="col-sm-4 product">Product View
            {/* {this.state.newdata.map((val,i) => <Productview key={i} data={val}/>)} */}
            {eval("["+localStorage.getItem("list")+"]").map((val,i) => <Productview key={i} data={val}/>)}
          </div>

        </div> 
     );
  }
}
export default Product;
