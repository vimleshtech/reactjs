import React,{Component} from 'react';
import './Header.css';

class CSSHeader extends  Component
{

    constructor(){
        super();
    }

    
    render(){

        // let className = 'menu';
        // if (this.props.isActive) {
        //   className += ' menu-active';
        // }

        // return <span className={className}>Menu</span>

        return(
            <div>
                    <div className="DottedBox">
                        <p className="DottedBox_content">Get started with CSS styling</p>
                    </div>

                    <div style={divStyle}>
                        <p style={pStyle}>Get started with inline style</p>
                    </div>
          </div>

        );
    }
}


const divStyle = {
    margin: '40px',
    border: '5px solid pink'
  };
  const pStyle = {
    fontSize: '15px',
    textAlign: 'center'
  };

export default CSSHeader;


//I recommend CSS Modules or regular CSS stylesheets.

//1. CSS Stylesheet
//2. Inline styling
//3. npm install --save bootstrap
