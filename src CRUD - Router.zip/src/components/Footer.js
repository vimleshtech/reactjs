import React, {Component} from 'react';

class Footer extends Component
{


    render()
    {

        return(

            <div>
                    <h3> Footer </h3>
            </div>
        );
    }
}

export default Footer;