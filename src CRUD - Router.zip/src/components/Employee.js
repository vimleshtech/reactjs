import React,{Component} from 'react';
import './Employee.css';



const dStyle = {
    width: '500px',
    textAlign: 'center'
  };


const pstyle ={
    color: "blue",
    fontSize: "24px"
};

class Employee extends Component{
    constructor(){
            super();
            this.state={
                    eid:0,
                    ename:'',
                    emailid:'',
                    salary:0,
                    emps:[]

            }

            this.eid = this.eid.bind(this);
            this.ename = this.ename.bind(this);
            this.emailid = this.emailid.bind(this);
            this.salary = this.salary.bind(this);

            this.submit = this.submit.bind(this);

            this.tourl = this.tourl.bind(this); 
    }
    eid(event)
    {
        var d = event.target.value;
        this.setState({eid:d});
    }

    ename(event)
    {
        var d = event.target.value;
        this.setState({ename:d});        
    }

    emailid(event)
    {
        var d = event.target.value;
        this.setState({emailid:d});        
    }

    salary(event)
    {
        var d = event.target.value;
        this.setState({salary:d});
        
    }
    submit()
    {
            var emp = this.state.emps;
            emp.push({eid:this.state.eid,ename:this.state.ename,emailid:this.state.emailid,salary:this.state.salary});

            //update state
            this.setState({emps:emp});
            
            //show /print in console 
            console.log(this.state.emps);


    }
    tourl(){

        //navigate to other url after click 
        this.props.history.push('/APICall')
        
    }
    render()
    {
        
        return(
                <div className="bd">
                    <div style={dStyle}>
                    <h1> Employee Registration .... </h1>
                    <p style={pstyle}> 
                            Employee ID 
                         <input type="text" 
                        className="form-control" placeholder="Employee ID"
                        onChange={this.eid} />
                    </p>
                    <p>
                         <input type="text"
                        className="form-control" 
                        placeholder="Employee Name"
                        onChange={this.ename} />
                    </p>
                    <p>
                        <input type="text" 
                        className="form-control"
                        placeholder="Employee Email ID"
                        onChange={this.emailid} />
                    </p>
                    <p>
                         <input type="text" 
                        className="form-control"
                        placeholder="Employee Salary"
                        onChange={this.salary} />
                    </p>
                    <p>
                        <input type="button" value="Add Employee"
                        className="btn btn-primary"
                         onClick={this.submit} />

        <input type="button" value="To URL"
                        className="btn btn-primary"
                         onClick={this.tourl} />


                    </p>

            <table className="table"> 
            <tbody> 
                    {this.state.emps.map((person, i) => <TableRow key = {i} data = {person} />)} 
            </tbody> 
            </table>

            </div>
        </div>
        );
    }
}
class TableRow extends Component 
{ 
    render() 
    { 
        return (
        <tr>
                <td>{this.props.data.eid}</td> 


                <td>{this.props.data.ename}</td>
                    
                <td>{this.props.data.emailid}</td>
                <td>{this.props.data.salary}</td>
                <td>

                <input type="button" value="Edit"
                        className="btn btn-primary"
                          />

                </td>
                <td>

                <input type="button" value="Delete"
                        className="btn btn-primary"
                          />

                </td>
                <td>
                <input type="button" value="Mark"
                        className="btn btn-primary"
                          />

                </td>

                
            </tr>
            ); 
        } 
}

export default Employee;

