import React,{Component} from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";


class APICall extends Component
{


    constructor()
    {
        super();
        this.state={
            eid:0,
            data:[]        
        }

        this.callAPI =      this.callAPI.bind(this);
        this.filterData = this.filterData.bind(this);

    }


    //get alld ata 
    callAPI()
    {
        var temp = this.state.data;
        fetch("https://jsonplaceholder.typicode.com/todos")
        .then(data => data.json())
        .then(
                    //out => console.log(out)
                    out=> temp.push(out)
        );

        this.setState({data:temp});
        console.log(this.state.data);

    }
    testFun(a,b)
    {

    }
    filterData(event)
    {

        var arg =  event.target.value;

        if(arg.length > 0)
        {
                
                console.log(arg);
                var uri ="https://jsonplaceholder.typicode.com/todos/"+arg;
                console.log(uri);


                var temp = [];
                fetch(uri)
                .then(data => data.json())
                .then(
                            out => console.log(out)
                            //out=> temp.push(out)
                );

                //this.setState({data:[]});
                //this.setState({data:temp});

                //console.log(this.state.data);

        }
    }
    render()
    {
        

        return(
            <div>
                  
                        <input value="Get Data" className="btn btn-dark" type="button" onClick={this.callAPI} />
                        <input type="input" onChange={this.filterData} />

                        <a href="http://localhost:3002/APICall/Product/10"> Tested Menu - Product </a>
{/* 
                        <div>
                                <h2>Topics</h2>
                                <ul>
                                    <li>
                                    <Link to={`${match.url}/rendering`}>Rendering with React</Link>
                                    </li>
                                    <li>
                                    <Link to={`${match.url}/components`}>Components</Link>
                                    </li>
                                    <li>
                                    <Link to={`${match.url}/props-v-state`}>Props v. State</Link>
                                    </li>
                                </ul>

                                <Route path={`${match.path}/:topicId`} component={Topic} />
                                <Route
                                    exact
                                    path={match.path}
                                    render={() => <h3>Please select a topic.</h3>}
                                />
                                </div> */}
                                
            </div>
            );
    }
}

function Topic({ match }) {
    return (
      <div>
        <h3>{match.params.topicId}</h3>
      </div>
    );
  }

  
export default APICall;
