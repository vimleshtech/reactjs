import React, {Component} from 'react';
import Navigation from './Navigation';

export default class Header extends Component {
    render(){
        return (
            <div>
                <Navigation/>
                <div className="container">
                    <h1> My Blog </h1>
                </div>
            </div>
        )
    }
}