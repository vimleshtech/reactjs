import React,{Component} from 'react';


class AllPost extends Component{

render(){

    return(

        <div>
                All posts 
        </div>

    );
}

}

export default AllPost;
