import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import './App.css';

import Header from './components/Header';
import Footer from './components/Footer';
import Body from './components/Body';
import Product from './components/Product';

import Employee from './components/Employee';

import PostForm from './components/PostForm';
import AllPost from './components/AllPost';

import APICall from './components/APICall';
import CSSHeader from './css/Header';

class App extends Component {
  
  render(){

    return (
        <div> 
          
          <Header/>
          
            {/* 
            <Body/>
            <Product/>
            <Footer/> */}
        <Router>
        <div>
          <ul>
            <li>
              <Link to="/">Employee</Link>
            </li>
            <li>
              <Link to="/APICall">APICall</Link>
            </li>
            <li>
              <Link to="/PostForm">PostForm</Link>
            </li>
          </ul>

          <hr />

          <Route exact path="/" component={Employee} />
          <Route path="/APICall" component={APICall} />
          <Route path="/PostForm" component={PostForm} />
          <Route path="/APICall/Product/:id?" component={Product} />

        </div>
        </Router>

            
            {/* <Employee/>
            
            <CSSHeader/>
            <APICall/>
            
            <PostForm />
            <AllPost /> */}

            
        </div>
    

  );
  }
}

export default App;
