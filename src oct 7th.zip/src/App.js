import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

  constructor()
  {
    super();
    this.state={
      name:'abcd',  
      data: [ 
        { "id"  :100, "name":"Raman", "age":"28" }, 
        { "id":200, "name":"Monika", "age":"22" } 
      ]

    }
  }
  render() {

    var i = 2;
    var myStyle = { fontSize: 30,color: '#FF0000' }

    return (
      
      <div>
        <h1>Interpolation Example </h1>
          Interpolation Result : {2*8}


      <h1> State Example </h1>
        Name : {this.state.name}


          {/* We cannot use if else statements inside JSX, instead we can use conditional (ternary) expressions. */}
        <h1>Ternary expressions Example</h1>
        <h2>{i == 2 ? 'True!' : 'False'}</h2>


        <h1>Style Example </h1>
        <h2 style = {myStyle}>Some Content</h2>


        <h1> Props Example </h1>
            <h2>{this.props.headerProp}</h2>
            <h2>{this.props.contentProp}</h2>


    <h1>EcmaScript 2015 arrow syntax (⇒) </h1>

        <table> 
          <tbody> 
            {this.state.data.map((val, i) =><TableRow key = {i} data = {val} />)} 

          </tbody> 
        </table>


      </div>

    );
  }
}
// Prop is immutable
App.defaultProps = {
  headerProp: "Header from props...",
  contentProp:"Content from props...",
  test:"abcd"
}

class TableRow extends React.Component 
{ 
  render() 
  { 
    return (
  
    <tr> 
      <td>{this.props.data.id}</td> 
      <td>{this.props.data.name}</td> 
      <td>{this.props.data.age}</td> </tr> ); 
      } 
  }
  
export default App;
