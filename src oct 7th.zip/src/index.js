import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';

// prop binding 
//The main difference between state and props is that props are immutable. This is why the container component should define the state that can be updated and changed
//  ReactDOM.render(<App headerProp = "from index..." contentProp = "Content.." />, document.getElementById('root'));

 ReactDOM.render(<App  />, document.getElementById('root'));

registerServiceWorker();
