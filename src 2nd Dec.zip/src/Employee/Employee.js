import React , {Component} from 'react';

class Employee extends Component {
   
    constructor() {
      super();
      this.state = {
         data: 
         [
            {
               "id":101,
               "name":"Raman",
               "age":"22"
            },
            {
               "id":201,
               "name":"Daphney Paul",
               "age":"40"
            },
            {
               "id":301,
               "name":"Chirs",
               "age":"31"
            }
         ]
      }
   }
   render() {
      return (
         <div>            
            <table>
               <tbody>
                  {this.state.data.map((person, i) => <TableRow key = {i} 
                     data = {person} />)}
               </tbody>
            </table>
         </div>
      );
   }
}

// props are immutable

class TableRow extends React.Component {
   render() {
      return (
         <tr>
            <td>{this.props.data.id}</td>
            <td>{this.props.data.name}</td>
            <td>{this.props.data.age}</td>
         </tr>
      );
   }
}
export default Employee;