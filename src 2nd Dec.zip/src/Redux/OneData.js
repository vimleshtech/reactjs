
//export  default  msg="This message from Redux block";
const uri="https://jsonplaceholder.typicode.com/todos/1";
export default uri;
//export default userid="absshss";
//export default pwd="pwd";




