
class test 
{
    callToFunction(msg)
    {

        var res;

        fetch(msg).then(res => res.json()).then(out =>
        res = out
        );

        return res;
    }
}

export default test;
