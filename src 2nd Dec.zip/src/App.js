import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import Header from './Header/Header';
import Employee from './Employee/Employee';
import PropsExample from './Props/PropsExample';
import SetEvent from './EventAndLifeCycle/SetEvent'
import LifeCycle from './EventAndLifeCycle/LifeCycle'
import FormEvent from './Forms/FormEvent'
import ButtonEvent from './Forms/ButtonEvent'
import Ref from './RefAndKey/Ref'
import Key from './RefAndKey/Key'
import Footer from './Footer/Footer';

//npm install 
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

class App extends Component {
  render() {
    return (
      <div className="App">

<Router>
      <div>
        <ul>
          <li>
            <Link to="/">Header</Link>
          </li>
          <li>
            <Link to="/Employee">Employee</Link>
          </li>
          <li>
            <Link to="/ButtonEvent">ButtonEvent</Link>
          </li>
        </ul>

        <hr />

        <Route exact path="/" component={Header} />
        <Route path="/ButtonEvent" component={ButtonEvent} />
        <Route path="/Employee" component={Employee} />
      </div>
    </Router>

      {/* <Header/> */}
  {/* 
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header> */}
         <LifeCycle/>
        {/*<FormEvent/>
        <ButtonEvent/> */}
        {/* <Ref/>
        <Key/> */}
        {/* <Employee/>
        <PropsExample/>
        <SetEvent/> */}
        {/* <Footer/> */}
      </div>
    );
  }
}

export default App;
