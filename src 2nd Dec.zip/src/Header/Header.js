import React,{Component} from 'react';

import msg from '../Redux/OneData';
import test from '../Redux/Action';


class Header extends Component{

    constructor()
    {

        super()
        this.state={
            data:[]
        }

        this.test = this.test.bind(this);

        this.obj = new test();
    }
    test()
    {
        //alert('hi');        
        //alert(msg);

        
        var cp ;

        cp = this.obj.callToFunction(msg);

        this.setState({data:cp});
        console.log(this.state.data);

    }
render(){
    //this.test();
    var i = 0;
    var myStyle = {
        fontSize: 100,
        color: '#FF0000'
     }

    return(

        

        <div>
              
            
            <h1>{i == 1 ? 'True!' : 'False'}</h1>

            <h1>Header</h1>
            <h2>Content</h2>
            <p>This is the content!!!</p>
            <h1 style = {myStyle}>Test</h1>
            <p>
            
            </p>
        </div>

    );
}

}

export default Header;