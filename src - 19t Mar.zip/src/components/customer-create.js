import React,{Component} from 'react';

import CustomerManage from './customer-manage';


export default class CustomerCreate extends Component{


    constructor(){
        super();

        this.state={

            customers:[],
            mcount:0,
            total:0,
            umcount:0,
            
        }
    }


    frm_submit=()=>{

        var id  = this.refs.id.value;
        var name  = this.refs.name.value;
        var email  = this.refs.email.value;
        var dob  = this.refs.dob.value;

        var customers  = this.state.customers;
        customers.push({cid:id,cname:name,cemail:email,cdob:dob,ismark:false});

        this.setState({customers:customers});
        console.log(this.state.customers);


        this.frm_clear();
        this.frm_summary();


    }
    frm_edit=(e)=>{
        
        var customer =  this.state.customers.filter(x => x.cid == e); 

        this.refs.id.value=customer[0].cid;
        this.refs.name.value=customer[0].cname;
        this.refs.email.value=customer[0].cemail;
        this.refs.dob.value=customer[0].cdob;

    }
    frm_delete=(e)=>{
        
       var customers =  this.state.customers.filter(x => x.cid != e);
       this.setState({customers:customers});
       this.frm_summary();

    }

    frm_update=()=>{

        var customers =  this.state.customers;

        for(let i =0; i<customers.length;i++)
        {
            if(customers[i].cid == this.refs.id.value){

                //customers[i].cid  = this.refs.id.value;
                customers[i].cname =  this.refs.name.value;
                customers[i].cemail =  this.refs.email.value;
                customers[i].cdob = this.refs.dob.value;

            }
        }
        this.setState({customers:customers});


    }
    frm_summary()
    {

           var mcount =  this.state.customers.filter(x => x.ismark == true).length;
           var total =  this.state.customers.length;
           var umcount = total-mcount;

           this.setState({total:total,mcount:mcount,umcount:umcount});


    }
    frm_clear(){

        this.refs.id.value="";
        this.refs.name.value="";
        this.refs.email.value="";
        this.refs.dob.value="";

    }
    render(){

        return(

            <div>
                    <h1>New Customer </h1>
                    <p>
                        <input type="number" className="form-control" ref="id"  placeholder="Customer ID"/>
                    </p>
                    <p>
                    </p>
                    <input type="text" className="form-control"  ref="name" placeholder="Customer Name"/>
                    <p>
                    </p>
                    <input type="email" className="form-control"  ref="email" placeholder="Customer Email"/>
                    <p>
                    <input type="date" className="form-control"  ref="dob" placeholder="Customer DOB"/>
                    </p>
                    <p>
                            <input type="button" className="btn btn-primary"
                             onClick={this.frm_submit} value="Add Customer" />
                         
                            <input type="button" className="btn btn-success"
                            onClick={this.frm_update} value="Update" />
                    </p>
                    

                    <div>
                    <h1> Summary </h1>
                    <h3> Total rows : {this.state.total} </h3>
                    <h3> Marked rows : {this.state.mcount} </h3>
                    <h3> Ummarked rows : {this.state.umcount} </h3>

                    </div>


                    <table className="table table-striped">
                    <thead>
                      <tr>
                      <th>Customer #</th>
                        <th>Name </th>                        
                        <th>Email</th>
                        <th>DOB</th>

                      </tr>
                    </thead>
                    <tbody>
                  
                    {this.state.customers.map((row,i)=>
                    
                        <CustomerManage 
                        frm_edit={this.frm_edit}
                        frm_delete={this.frm_delete} rowitem={row} key={i} />                 
                     )}
                
                </tbody>
                </table>



                    
            </div>


        );
    }

}
