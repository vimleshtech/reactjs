import React,{Component} from 'react';

export default class CustomerManage extends Component{


    constructor(){
        super();
    }
    render(){

        return(

<tr>
            <td>{this.props.rowitem.cid}</td>
            <td>{this.props.rowitem.cname}</td>
            <td>{this.props.rowitem.cemail}</td>
            <td>{this.props.rowitem.cdob}</td>
            <td>
                <input type="button" 
                onClick={()=>this.props.frm_delete(this.props.rowitem.cid)} value="Delete" />
            </td>
            <td>
            <input type="button" 
                onClick={()=>this.props.frm_edit(this.props.rowitem.cid)} value="Edit" />

            </td>


</tr>

        );
    }

}
