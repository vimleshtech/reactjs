import React,{Component} from 'react';
import ReactDOM from 'react-dom'
import CustomerShow from './customer-manage';

export default class CustomerCreate extends Component{

constructor(){
    super();
    this.state={
        customers:[],
        readonly:false,
        total:0,
        markcount:0,
        umarkcount:0
    }
}


frm_submit=()=>{

    var id = ReactDOM.findDOMNode(this.refs.id).value;
    var name = ReactDOM.findDOMNode(this.refs.name).value;
    var email = ReactDOM.findDOMNode(this.refs.email).value;
    var phone = ReactDOM.findDOMNode(this.refs.phone).value;
    var dob =this.refs.dob.value;

    var customers = this.state.customers;
    customers.push({cid:id,cname:name,cemail:email,cphone:phone,cdob:dob,ismark:false});
    this.setState({customers:customers});
    console.log(customers);

    this.frm_clear();
    this.frm_markCount();
}
row_delete=(e)=>{

    var customers = this.state.customers;
    //customers.splice(e,1);
    customers = customers.filter(x=> x.cid !== e);
    this.setState({customers:customers});

    this.frm_markCount();

}

row_edit=(e)=>{

    var customer = this.state.customers.filter(x=>x.cid===e);

    this.refs.id.value =customer[0].cid;
    this.refs.name.value =customer[0].cname;
    this.refs.email.value =customer[0].cemail;
    this.refs.phone.value =customer[0].cphone;
    this.refs.dob.value =customer[0].cdob;
    
    this.setState({readonly:true});

}
frm_update=()=>{
    var id = this.refs.id.value;
    var name = this.refs.name.value;
    var email = this.refs.email.value;
    var phone = this.refs.phone.value;
    var dob =this.refs.dob.value;

    var customers = this.state.customers;
    for(let i=0; i<customers.length;i++){
        if(customers[i].cid == id)
        {
            customers[i].cname=name;
            customers[i].cemail=email;
            customers[i].cphone=phone;
            customers[i].cdob=dob;

        }
    }
    this.setState({customers:customers});

    this.setState({readonly:false});

    this.frm_clear();
}

row_mark=(e)=>{

    var customers = this.state.customers;
    
    for(let i=0; i<customers.length;i++){
        if(customers[i].cid === e)
        {
            customers[i].ismark = !customers[i].ismark;

        }
    }
    this.setState({customers:customers});

    this.frm_markCount();

}
frm_clear(){
    
    this.refs.id.value="";
    this.refs.name.value="";
    this.refs.email.value="";
    this.refs.phone.value="";
    this.refs.dob.value="";
    
}
frm_markCount(){
    var customers = this.state.customers;
    var mcount =customers.filter(x=> x.ismark ===true).length;
    var umcount = customers.length- mcount;
    var total = customers.length;

    this.setState({total:total,markcount:mcount,umarkcount:umcount});

}
render(){

    const isReadonly = this.state.readonly;

    return(
        <div>
        <h1>New Customer </h1>
        <p>

            <input type="number" ref="id" readOnly={this.state.readonly} required  className="form-control" placeholder="Customer id"/> 
        </p>
        <p>

            <input type="input" ref="name"   className="form-control" required placeholder="Customer name"/> 
        </p>
        <p>
            <input type="email" ref="email"   className="form-control" required placeholder="Customer email"/> 
        </p>
        <p>
            <input type="number" ref="phone"   className="form-control" required placeholder="Customer phone no"/> 
        </p>
        <p>
            <input type="date" ref="dob"   className="form-control" required placeholder="Customer dob"/> 
        </p>
        <p>
             {isReadonly ? (
                <input type="button" onClick={this.frm_update}  className="btn btn-primary" value="Update Customer Details"/> 
            ) : (
                <input type="button" onClick={this.frm_submit}  className="btn btn-primary" value="Add Customer"/> 

            )}
            
        

        </p>

        <h1> Customer Details </h1>        
        <p>
            Total Rows : {this.state.total}
        </p>
        <p>
            Marked Rows : {this.state.markcount}
        </p>
        <p>
            Unmarked Rows : {this.state.umarkcount}
        </p>
        <table className="table table-striped">
        <thead>
        <tr>
            <th>Customer #</th>
            <th>Name</th>
            <th>Email ID </th>
            <th>Phone</th>
            <th>DOB</th>
        </tr>
        </thead>
        <tbody>

            {this.state.customers.map((item,i)=>
                <CustomerShow row_delete={this.row_delete} row_edit={this.row_edit}
                row_mark={this.row_mark} rowitem={item} key={i} />
            ) }

        </tbody>
        </table>

        
        </div>
    )
}


}

