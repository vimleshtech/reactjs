import React,{Component} from 'react';

export default class  CustomerShow extends Component{

    render(){

        var color= this.props.rowitem.ismark?'red':'';

        return(

            <tr style={{backgroundColor: color}}>
                
                <td> {this.props.rowitem.cid}</td> 
                <td>{this.props.rowitem.cname} </td>
                <td>{this.props.rowitem.cemail}</td> 
                <td>{this.props.rowitem.cphone} </td>
                <td>{this.props.rowitem.cdob}</td>


                <td>
                <input type="button" onClick={()=>this.props.row_edit(this.props.rowitem.cid)} className="btn btn-success" value="Edit" />
                </td>

                <td>    
                <input type="button" onClick={()=>this.props.row_delete(this.props.rowitem.cid)} className="btn btn-danger" value="Delete" />
                </td>
                <td>    
                <input type="checkbox" onClick={()=>this.props.row_mark(this.props.rowitem.cid)}  value="Mark" />
                </td>
         

            </tr>
        )
    }

}
