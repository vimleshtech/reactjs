import React,{Component} from 'react';

import { connect } from 'react-redux';


 class ProductList extends Component{

    render(){

        return(
            <div>
                

                <div>
                    {/* {console.log(this.props.posts)} */}

                    {this.props.posts.map((item,i)=>
                        <p key={i}> {item.name} </p>                    
                    )}
                </div>


                


            </div>


        );
    }


}

const mapStateToProps = (state) => {
    return {
        posts: state
    }
}


export default  connect(mapStateToProps)(ProductList);

 