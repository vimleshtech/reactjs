var express = require('express');
var  mysql  = require('mysql');
var  config = require('./config.js');

let connection = mysql.createConnection(config);
var app = express();

app.get('/', function(req, res) {
        
        res.json({ a: 100 });
        
        //res.send(JSON.stringify({value: 1}));
    
    
    });
    
 app.get('/savedata',function(req,res){


    var name = req.param('n');
    var pwd = req.param('p');

    //let sql ="insert into users(name,pwd) values('nitin','nit1234')";
    let sql ="insert into users(name,pwd) values('"+name+"','"+pwd+"')";

    // execute the insert statment
    connection.query(sql);        
    connection.end();

    res.send("data is saved");

 });   

app.listen(3010, function() {
  
    console.log('Example app listening on port 3010!');

});



