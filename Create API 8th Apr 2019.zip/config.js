
let config = {
    host    : 'localhost',
    user    : 'root',
    password: 'root',
    database: 'db_react'
  };
   
  module.exports = config;
  